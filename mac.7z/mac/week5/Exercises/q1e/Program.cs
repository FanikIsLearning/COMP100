﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q1e
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("+=========================+");
            Console.WriteLine("+   Centennial College    +");
            Console.WriteLine("+   941 Progress Avenue   +");
            Console.WriteLine("+   Scarborough, ON       +");
            Console.WriteLine("+=========================+");
        }
    }
}
